import { Button, Card } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import Immutable from "immutable";
import React from "react";
import { useState } from 'react';

type numberArray = number[]
type PageProbTuple = [number, number]; // [page number, lix]
class LIXMap {
    p: number = 0
    timestamp: Date = new Date()
    freq:number = 0
    lix: number = 0
    diskNum: number = -1
}

type LIXProps = {
    broadcast :numberArray[]
    disks: number
    tracksArray: numberArray[]
    pageFreqProbMap: Immutable.Map<number,number>
    lixArray: number[]
}

type DiskPagePair = {
    disk: number;
    page: number;
  }
export const LIX: React.FunctionComponent<LIXProps> = (props) => {
    const {broadcast, disks, tracksArray, pageFreqProbMap, lixArray } = props
    const [rows, setRows] = React.useState<PageProbTuple[]>([]);
    const columns = [
        {field: 'id', headerName: 'Current Time', width: 150 },
        { field: 'page', headerName: 'Page Number', width: 150 },
        { field: 'lix', headerName: 'LIX', width: 350 },
      ];
    const getDiskNum :(pageNum: number) => number =(pageNum)=> {

        for(var i = 0; i <= tracksArray.length; i++){
            const entryArray = tracksArray[i]
            if (entryArray.findIndex(t => t === pageNum) !== -1)
                return i+1
        }
        return -1
    }

    const findMinLixEntry = () => {
       ///return lixProbMap.entrySeq().reduce((r,v) => v[1].lix < r ? v[0]: -1, Infinity)
       const lixMapArray = lixProbMap.entrySeq()
       var key = -1
       var minSoFar = Infinity
       lixMapArray.forEach((entry) => {
         if(entry[1].lix < minSoFar){
            minSoFar = entry[1].lix
            key = entry[0]
         }
       })
       return key
    }
    //const lixArray = Array.from({length:disks}, (x,i) => i+1)
    //console.log("lixArray", lixArray)
    type DiskPagePairArray = DiskPagePair[]
    const [chains, setChains] = useState<DiskPagePairArray[]>(Array.from({length: disks}, (x,i) => []))
    
    //setDisksArray(Array.from({length:disks}, (x,i) => i+1))
    var lixProbMapT = Immutable.Map<number,LIXMap>()

        // pageFreqProbMap.keySeq().forEach( (key) => {
        //     const lixmap = new LIXMap()
        //     lixmap.freq = pageFreqProbMap.get(key)!
        //     //lixmap.diskNum = getDiskNum(key)
        //     lixProbMapT = lixProbMapT.set(key, lixmap)
        //     })
        
        const [lixProbMap, setLixProbMap] = React.useState(lixProbMapT)
    
        React.useEffect(() => { 
            if (!lixProbMap || lixProbMap.keySeq().toArray().length === 0)
                setLixProbMap(lixProbMapT)
            if(!chains || chains.length === 0 )
                setChains(Array.from({length: disks}, (x,i) => []))
        }, [lixProbMap, rows,chains] )
        
    const queueSize = 2
    //const queueArray = Array.from({length:queueSize}, (x,i) => i+1)
    
   // const lixArray = Array.from({length:disks}, (x,i) => i+1)
   // const victimTracker:number = -1
    const [victimTracker, setVictimTracker] = useState<DiskPagePair[]>([])
    const DELTA = 0.25

    const [lowestLix, setLowestLix] = useState(Infinity);

    const [highestLix, setHighestLix] = useState(Array.from({length: disks}, (x,i) => -1));

    const [highestLixPage, setHighestLixPage] = useState(-1);

    const [lowestLixPage, setLowestLixPage] = useState(-1);

    const similateLixAccess = () => {

        const keys = pageFreqProbMap.keySeq().toArray()
        var randomPageToAccess = keys[Math.floor(Math.random() * keys.length)];
        //randomPageToAccess =8
        //console.log(randomPageToAccess)
        var lixMap = lixProbMap.get(randomPageToAccess)!
        if(!lixMap){
            lixMap = new LIXMap()
        }
        const currentTime = new Date()
        const p_i = DELTA/(currentTime - lixMap.timestamp+1) + (1 - DELTA)*lixMap.p
        lixMap.diskNum = getDiskNum(randomPageToAccess)
        lixMap.p = p_i
        lixMap.lix = lixMap.p/pageFreqProbMap.get(randomPageToAccess)!
        lixMap.timestamp = currentTime
        //console.log(lixMap.lix)
        //console.log(highestLix)
        var diskAdd = getDiskNum( randomPageToAccess)
        //console.log("chains", chains)
        //console.log("diskAdd", diskAdd)
        //console.log('lixArray',lixArray)
        var added = false
        const totalPagesInCache = chains.flat().length
        if (totalPagesInCache < 4 )
       {     
            console.log("Hpage", randomPageToAccess)
            setHighestLixPage(randomPageToAccess);
            var diskAdd = getDiskNum( randomPageToAccess)
            console.log("Hdisk",diskAdd)
            var chainTemp = chains
            if(!(chainTemp[diskAdd-1].filter(entry => entry.page === randomPageToAccess).length > 0)){
                chainTemp[diskAdd-1].push({ disk: diskAdd, page:  randomPageToAccess})
                setLixProbMap(lixProbMap.set(randomPageToAccess,lixMap))
                added = true
                setChains(chainTemp);
                console.log('chainTemp',chainTemp)
                console.log('chain',chains)
            }
       }else if (totalPagesInCache >= 4){
        //victim
        var diskAdd = getDiskNum( randomPageToAccess)   
        const minLixEntry = findMinLixEntry()
        console.log(lixProbMap)
        console.log('minLixEntry page', minLixEntry)
        console.log('minLixEntry disk',getDiskNum(minLixEntry))
        var chainTemp = chains
        const removed = chainTemp[getDiskNum(minLixEntry)-1].filter(entry => entry.page !== minLixEntry)
        chainTemp[getDiskNum(minLixEntry)-1] = removed
        if(!(chainTemp[diskAdd-1].filter(entry => entry.page === randomPageToAccess).length > 0)){
            chainTemp[diskAdd-1].push({ disk: diskAdd, page:  randomPageToAccess})
            //setLixProbMap(lixProbMap.remove(minLixEntry))
            setVictimTracker([...victimTracker, {disk: getDiskNum(minLixEntry), page:  minLixEntry}])
            setChains(chainTemp);
            setLixProbMap(lixProbMap.set(randomPageToAccess,lixMap).remove(minLixEntry))
            added = true
        }
                
       }

        // if (highestLix !== -1 && lixMap.lix < lowestLix && chain[diskAdd].>2) {
        //     setLowestLix(lixMap.lix);
        //     setLowestLixPage(randomPageToAccess);
        //     var diskRemove = getDiskNum( randomPageToAccess)
        //     console.log("Lpage", randomPageToAccess)
        //     console.log("Ldisk",diskRemove)
        //     setVictimTracker((prev) => [...prev, {disk:diskRemove,page:randomPageToAccess}]);
        //     setChains(chains.filter((queue) => queue.page !== randomPageToAccess));
        //   }
        
        //var diskRemove = getDiskNum(lowestLixPage)
       
        
   
        //var diskAdd = getDiskNum(highestLixPage)
     

       
        if(added)
            setRows((prevRows) => [...prevRows, { id: currentTime.toTimeString().split(' ')[0],  page: randomPageToAccess, lix: lixMap.lix }]);
        added = false
    }

    return(
        <div>
            <Button variant="contained" disabled={broadcast.length === 0 } onClick={() => similateLixAccess()}> Simulate LIX </Button>
            <Card>
            <div>
                {lixArray.map((num) => {
                    return (<div>
                        <span>LIX Queue #{num} : </span>
                        {chains[num-1]?.map((entry) => entry.page).toString()}
                    </div> )                  
                })}
            </div>
             {/* {lixArray && lixArray.map((num) => (
            <div>
                LIX Queue #{num}
                {chains[num-1].map((queue) => (
                (queue.disk === num) ? <Button key={queue.page}>{queue.page}</Button> : null
                ))}
            </div>
            ))}
                */}
                Victim  {victimTracker.map((item, index) => (
                <Button key={index}>
                    Disk {item.disk} : Page {item.page} 
                </Button>
                ))}
            </Card>
            <div style={{ height: 400, width: '100%' }}>
        <DataGrid rows={rows} columns={columns} pageSize={5}/>
      </div>
        </div>
        
    )
}

export default LIX