import React from 'react';
import './App.css';
import { Button, TextField } from '@mui/material';
import Immutable, { Map } from 'immutable';
import LIX from './LIX';

function App() {

  const colorArray = ["success", "warning", "info", "error"]
  type numberArray = number[]
  const [pages, setPages] = React.useState(0)
  const [pageArray, setPageArray] = React.useState<number[]>([])
  const [disks, setDisks] = React.useState(0)
  const [disksArray, setDisksArray] = React.useState<number[]>([])
  const [pageFreqProbMap, setPageFreqProbMap] = React.useState<Map<number,number>>(Immutable.Map<number, number>())
  const [diskItemCountMap, setDiskItemCountMap] = React.useState<Map<number,number>>(Immutable.Map<number, number>())
  const [numChunksMap, setNumChunksMap] = React.useState<Map<number,number>>(Immutable.Map<number, number>())
  const [maxChunks, setMaxChunks] = React.useState(0)
  const [chunksMap, setChunksMap] = React.useState(Immutable.Map<number, numberArray[]>())
  const [broadcast, setBroadcast] = React.useState<numberArray[]>([])
  const [broadcastMap, setBroadcastMap] = React.useState<Immutable.Map<number,numberArray[]>>(Immutable.Map())
  const [tracksArray, setTracksArray] = React.useState<numberArray[]>([])
  const updateDiskItemCountMap = (i: number, val: number) => {
    setDiskItemCountMap(diskItemCountMap.set(i,val))
  }

  const updatePageFreqProbMap = (i: number, val: number) => {
    setPageFreqProbMap(pageFreqProbMap.set(i,val))
  }

  function lcm(numbers:number[]) {
    function gcd(a:number, b:number) : number {
      // If the second argument is 0, return the first argument (base case)
      if (b === 0) {
        return a;
      }
      // Otherwise, recursively call gcd with arguments b and the remainder of a divided by b
      return gcd(b, a % b);
    }
    // Reduce the array of numbers by multiplying each number together and dividing by their gcd
    // This finds the Least Common Multiple (LCM) of the numbers in the array
    return numbers.reduce((a, b) => a * b / gcd(a, b));
  }

  

  const sort = () => {
    const pageArraySorted = pageArray.sort((a, b) => {
      const aValue = pageFreqProbMap.get(a) ?? 0
      const bValue = pageFreqProbMap.get(b) ?? 0
      return bValue - aValue
    })
   
   
    setPageArray(pageArraySorted)
    console.log("page",pageArray)
  }

  const runAlgo = () => {
    console.log("page",pageArray)
    //const sortedPageFreqProbMap = pageFreqProbMap.sortBy((value, key) => -value).toOrderedMap()
    //setPageFreqProbMap(sortedPageFreqProbMap)
    const freqSeq = pageFreqProbMap.valueSeq().toSet().toArray()
    console.log("frq",freqSeq )
    const maxChunksT = lcm(pageFreqProbMap.valueSeq().toArray())
    var numChunksMapTemp = numChunksMap
    disksArray.forEach( key => {
      numChunksMapTemp = numChunksMapTemp.set(key, maxChunksT / freqSeq[key-1]  )
    })
    console.log(numChunksMapTemp)
    var idx = 0
    var tracksArrayT: numberArray[] = []
    console.log(diskItemCountMap)
    diskItemCountMap.valueSeq().toArray().forEach((value) => {
          var chunk = pageArray.slice(idx,idx+value)
          idx = idx+ value
          tracksArrayT.push(chunk)
      }
    )
    console.log(tracksArrayT)
    var chunksMapT = Immutable.Map<number,numberArray[]>()
    
    tracksArrayT.forEach( (trackArray,i) => {
      var chunksArray: numberArray[] = []
      const chunkSize = trackArray.length / numChunksMapTemp.get(i+1)!
      
      for (let i = 0; i < trackArray.length; i += chunkSize) {
       const chunk = trackArray.slice(i, i + chunkSize);
         // do whatever
         chunksArray.push(chunk)
         
       }
       chunksMapT = chunksMapT.set(i, chunksArray)
    })
    //console.log(chunksMapT)
    var broadcastT:numberArray[]= []
    var broadcastMapT:Immutable.Map<number,numberArray[]>=Immutable.Map()

    //console.log(numChunksMapTemp)
    //console.log(maxChunksT)
    //console.log(disks)
    for(var i = 0 ; i <= maxChunksT -1 ; i++){
      for (var j = 1 ; j <= disks; j ++){
        //console.log(chunksMapT.get(j-1)![i%numChunksMapTemp.get(j)!])
        broadcastT.push(chunksMapT.get(j-1)![i%numChunksMapTemp.get(j)!])
        var existingArray =  broadcastMapT.get(j) ? broadcastMapT.get(j) : []
        existingArray?.push(chunksMapT.get(j-1)![i%numChunksMapTemp.get(j)!])
        broadcastMapT = broadcastMapT.set(j,existingArray!)
      }
    }
    console.log(chunksMapT)
    setTracksArray(tracksArrayT)
    //console.log(broadcastT)
    setChunksMap(chunksMapT)
    setNumChunksMap(numChunksMapTemp)
    setBroadcast(broadcastT)
    setMaxChunks(maxChunksT)
    setBroadcastMap(broadcastMapT)
    
  }
    
 var textFieldData = pageArray.map((i) => ({
    index: i,
    value: pageFreqProbMap.get(i) || 0,
  }));
  
  textFieldData.sort((a, b) => b.value - a.value);
  React.useEffect(() => {

  
     textFieldData = pageArray.map((i) => ({
      index: i,
      value: pageFreqProbMap.get(i) || 0,
    }));
    
    textFieldData.sort((a, b) => a.value - b.value);
    setPageArray(Array.from({length:pages}, (x,i) => i+1))
    setDisksArray(Array.from({length:disks}, (x,i) => i+1))

  }, [pages, disks, pageFreqProbMap, numChunksMap, maxChunks, chunksMap, broadcast,pageArray])

  return (
    <div className='App' style={{margin: "40px"}}> 
      <div>
        Number of pages? <TextField value={pages} type="number" onChange={(val) => setPages(parseInt(val.target.value))}></TextField>
      </div>
      <div>
      {
         textFieldData.map( (i) => (
          <Button variant={'contained'} style={{margin:"10px"}} key={`button-${i.index}`}>{i.index}</Button>
        ))
      }
      </div>
      <div>
      {
      textFieldData.map((i) => (
        <TextField
          style={{ margin: "10px" }}
          key={i.index}
          size={"medium"}
          onChange={(e) => updatePageFreqProbMap(i.index, parseInt(e.target.value))}
          label={`Prob/Freq for page ${i.index}`}
          value={pageFreqProbMap.get(i.index) ? pageFreqProbMap.get(i.index) : 0}
        ></TextField>
        ))
        }
      {/*<div>
        <Button variant={'contained'} onClick={() => sort()}>Arrange/Sort</Button>
      </div>*/}
      <div>
        Number of Disks? 
        <TextField  value={disks} type="number" onChange={(val) => {setDisks(parseInt(val.target.value));sort()}}></TextField>
      </div>
      <div>
      {
        disksArray.map( (i) => (<TextField style={{margin:"10px"}} size={"medium"} label={`# of items in disk ${i}`} onChange={(e) => updateDiskItemCountMap(i, parseInt(e.target.value))} helperText={`Num Chunks : ${numChunksMap.get(i) ? numChunksMap.get(i) : 'tbd'}`} key={i}></TextField>
        ))
      }
      </div>
      <div>
        <Button type="button" variant={'contained'} onClick={() => runAlgo()}>Generate Broadcast Program</Button>
      </div>
      <div>
       max_chunks/LCM = <TextField disabled value={maxChunks}></TextField>
      </div>
      Broadcast Program:
      <div></div>
      {
        broadcast.map((arr,i) => (
          <Button style={{margin:"10px"}}  key={i}  variant='contained' color={colorArray[i%disks]}>{arr.toString()}</Button>
        ))
      }
    <div>
      <LIX broadcast={broadcast} disks={disks} tracksArray={tracksArray} pageFreqProbMap={pageFreqProbMap} lixArray={Array.from({length:disks}, (x,i) => i+1)}></LIX>
    </div>
    </div>
    </div>
  );
}

export default App;
